
-- used for specialaztion	
	CREATE TABLE Specialization (
    SpecializationId INT PRIMARY KEY IDENTITY (1, 1),
    SpecializationName VARCHAR (100) NOT NULL,
    SpecializationDescription NVARCHAR (max) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);
	CREATE TABLE Address (
    AdressId INT PRIMARY KEY IDENTITY (1, 1),
	HouseNumber VARCHAR (20),
    StreetName VARCHAR (100) NOT NULL,
    District NVARCHAR (100) NOT NULL,
	States varchar(100) NOT NULL,
	Country varchar(100) NOT NULL,
	PinCode varchar(20) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

CREATE TABLE LoginDetails (
    LoginId INT PRIMARY KEY IDENTITY (1, 1),
	UserName VARCHAR(255) Not Null,
    Password NVARCHAR (max) NOT NULL,
    CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

CREATE NONCLUSTERED INDEX [IX_NonClusteredIndex_Password]
ON LoginDetails (UserName)
INCLUDE (LoginId,Password)

	CREATE TABLE DoctorDetails (
    DoctorId INT PRIMARY KEY IDENTITY (1, 1),
	SpecializationId INT FOREIGN KEY REFERENCES Specialization(SpecializationId),
	LoginId INT FOREIGN KEY REFERENCES LoginDetails(LoginId),
    FirstName VARCHAR (100) NOT NULL,
    LastName NVARCHAR (max) NOT NULL,
	Email VARCHAR(255) NOT  NULL,
	PhoneNumber varchar(10) NOT NULL 
		constraint CK_MyTable_PhoneNumber check (PhoneNumber like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	AddressId INT FOREIGN KEY REFERENCES Address(AdressId),
	Description NVARCHAR (max) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

CREATE TABLE AppointmentStatus (
	StatusId INT PRIMARY KEY IDENTITY (1, 1),
    StatusName VARCHAR (100) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

CREATE TABLE Appointment (
	AppointmentId INT PRIMARY KEY IDENTITY (1, 1),
    DoctorId INT FOREIGN KEY REFERENCES DoctorDetails(DoctorId),
	StatusId INT FOREIGN KEY REFERENCES AppointmentStatus(StatusId),
	PatientPhoneNumber varchar(10) NOT NULL 
		constraint CK_Appointment_PhoneNumber check (PatientPhoneNumber like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	PatientEmail VARCHAR(255) NOT  NULL,
	SymptomsDescription NVARCHAR (max) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

CREATE TABLE AppointmentArchive (
	AppointmentArchiveId INT PRIMARY KEY IDENTITY (1, 1),
	AppointmentId INT FOREIGN KEY REFERENCES Appointment(AppointmentId),
    DoctorId INT FOREIGN KEY REFERENCES DoctorDetails(DoctorId),
	StatusId INT FOREIGN KEY REFERENCES AppointmentStatus(StatusId),
	PatientPhoneNumber varchar(10) NOT NULL ,
	PatientEmail VARCHAR(255) NOT  NULL,
	SymptomsDescription NVARCHAR (max) NOT NULL,
	CreatedDate Date Not Null,
	ModifiedDate Date Null,
);

insert into AppointmentStatus 
values ('Created',GetDate(),null),
('Rejected',GetDate(),null),
('Completed',GetDate(),null);







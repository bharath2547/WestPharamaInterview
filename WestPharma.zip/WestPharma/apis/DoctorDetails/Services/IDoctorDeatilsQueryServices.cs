﻿using DoctorDetailsService.Models;
using DoctorDetailsService.Models.DataModels;

namespace DoctorDetailsService.Services
{
    public interface IDoctorDeatilsQueryServices
    {
        Task<List<Models.DoctorDetailsResponse>> GetDoctorDeatils(int specilazationId);

        Task<List<SpecializationDataModel>> GetSpecializationDeatils();
    }
}

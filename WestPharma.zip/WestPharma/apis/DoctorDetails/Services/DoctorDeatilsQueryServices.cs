﻿using DoctorDetailsService.DbContextConfigurations;
using DoctorDetailsService.Models;
using DoctorDetailsService.Models.DataModels;
using Microsoft.EntityFrameworkCore;

namespace DoctorDetailsService.Services
{
    public class DoctorDeatilsQueryServices : IDoctorDeatilsQueryServices
    {
        private readonly WestPharmaDbContext _westPharmaDbContext;

        public DoctorDeatilsQueryServices(WestPharmaDbContext westPharmaDbContext)
        {
            _westPharmaDbContext = westPharmaDbContext;
        }

        public async Task<List<DoctorDetailsResponse>> GetDoctorDeatils(int specilazationId)
        {
            return  (from doctorDeatils in _westPharmaDbContext.Set<DoctorDetailsDataModel>().Where(x => x.SpecializationId == specilazationId)
                    join address in _westPharmaDbContext.Set<AddressDataModel>()
                    on doctorDeatils.AddressId equals address.AdressId
                    join specialization in _westPharmaDbContext.Set<SpecializationDataModel>()
                    on doctorDeatils.SpecializationId equals specialization.SpecializationId
                    select new DoctorDetailsResponse(doctorDeatils, address, specialization)).ToList();
        }

        public async Task<List<SpecializationDataModel>> GetSpecializationDeatils()
        {
            return await _westPharmaDbContext.Set<SpecializationDataModel>().ToListAsync();

        }
    }
}

﻿
using DoctorDetailsService.EntityConfigurations;
using DoctorDetailsService.Models;
using Microsoft.EntityFrameworkCore;

namespace DoctorDetailsService.DbContextConfigurations
{
    public class WestPharmaDbContext : DbContext
    {
        public WestPharmaDbContext(DbContextOptions<WestPharmaDbContext> context) : base(context)
        {
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            ChangeTracker.AutoDetectChangesEnabled = false;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new SpecializationEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new DoctorDetailsEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new AddressEntityTypeConfiguration());
        }
        
    }
}

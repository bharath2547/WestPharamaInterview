﻿using DoctorDetailsService.Services;
using Microsoft.AspNetCore.Mvc;

namespace DoctorDetailsService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DoctorDeatilsApi : ControllerBase
    {
        private readonly IDoctorDeatilsQueryServices _doctorDeatilsQueryServices;
        public DoctorDeatilsApi(IDoctorDeatilsQueryServices doctorDeatilsQueryServices)
        {
            _doctorDeatilsQueryServices = doctorDeatilsQueryServices;
        }

        [HttpGet]
        [Route("/Specializations")]
        public async Task<IActionResult> GetSpecializationAsync()
        {
            return Ok(await _doctorDeatilsQueryServices.GetSpecializationDeatils());
        }

        [HttpGet]
        [Route("/DoctorDeatils/Specializations/{SpecializationId}")]
        public async Task<IActionResult> GetDoctorDeatilsAsync([FromRoute(Name = "SpecializationId")]int id)
        {
            if(id > 0)
                return Ok(await _doctorDeatilsQueryServices.GetDoctorDeatils(id));
            return BadRequest();
        }

    }
}

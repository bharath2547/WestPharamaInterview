﻿using DoctorDetailsService.Models.DataModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DoctorDetailsService.EntityConfigurations
{
    public class SpecializationEntityTypeConfiguration : IEntityTypeConfiguration<SpecializationDataModel>
    {
        public void Configure(EntityTypeBuilder<SpecializationDataModel> builder)
        {
            builder.ToTable("Specialization");
            builder.HasKey(x => new { x.SpecializationId }).HasName("SpecializationId"); ;
            builder.Property(x=>x.SpecializationName).HasColumnName("SpecializationName");
            builder.Property(x => x.SpecializationDescription).HasColumnName("SpecializationDescription");
        }
    }
}

﻿using DoctorDetailsService.Models.DataModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DoctorDetailsService.EntityConfigurations
{
    public class AddressEntityTypeConfiguration : IEntityTypeConfiguration<AddressDataModel>
    {
        public void Configure(EntityTypeBuilder<AddressDataModel> builder)
        {
            builder.ToTable("Address");
            builder.HasKey(x => new { x.AdressId }).HasName("AdressId"); ;
            builder.Property(x => x.HouseNumber).HasColumnName("HouseNumber");
            builder.Property(x => x.StreetName).HasColumnName("StreetName");
            builder.Property(x => x.District).HasColumnName("District");
            builder.Property(x => x.States).HasColumnName("States");
            builder.Property(x => x.Country).HasColumnName("Country");
            builder.Property(x => x.PinCode).HasColumnName("PinCode");
        }
    }
}

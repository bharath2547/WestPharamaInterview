﻿using DoctorDetailsService.Models.DataModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DoctorDetailsService.EntityConfigurations
{
    public class DoctorDetailsEntityTypeConfiguration : IEntityTypeConfiguration<DoctorDetailsDataModel>
    {
        public void Configure(EntityTypeBuilder<DoctorDetailsDataModel> builder)
        {
            builder.ToTable("DoctorDetails");
            builder.HasKey(x => new { x.DoctorId }).HasName("DoctorId"); ;
            builder.Property(x => x.SpecializationId).HasColumnName("SpecializationId");
            builder.Property(x => x.AddressId).HasColumnName("AddressId");
            builder.Property(x => x.FirstName).HasColumnName("FirstName");
            builder.Property(x => x.LastName).HasColumnName("LastName");
            builder.Property(x => x.PhoneNumber).HasColumnName("PhoneNumber");
            builder.Property(x => x.Description).HasColumnName("Description");
            builder.Property(x => x.Email).HasColumnName("Email");
        }
    }
}

﻿using DoctorDetailsService.Models.DataModels;
using System.ComponentModel.DataAnnotations;

namespace DoctorDetailsService.Models
{
    public class DoctorDetailsResponse
    {
        public DoctorDetailsResponse(DoctorDetailsDataModel doctorDeatils, AddressDataModel address, SpecializationDataModel specialization)
        {
            DoctorId = doctorDeatils.DoctorId;
            DoctorName = doctorDeatils.FirstName + doctorDeatils.LastName;
            Email = doctorDeatils.Email;
            PhoneNumber = doctorDeatils.PhoneNumber;
            Description = doctorDeatils.Description;
            Address = address.HouseNumber+", "+address.StreetName+", "+ address.District;
            Specialization = specialization;
        }

        
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }

        public string Description { get; set; }

        public string Address { get; set; }

        public SpecializationDataModel Specialization { get; set; }

       
    }
}

﻿namespace DoctorDetailsService.Models.DataModels
{
    public class SpecializationDataModel
    {
        public int SpecializationId { get; set; }

        public string SpecializationName { get; set; }

        public string SpecializationDescription { get; set; }
    }
}

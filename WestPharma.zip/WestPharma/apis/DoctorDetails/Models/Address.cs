﻿using System.ComponentModel.DataAnnotations;

namespace DoctorDetailsService.Models
{
    public class Address
    {
        [Key]
        public int AdressId { get; set; }
        public string HouseNumber { get; set; }

        public string StreetName { get; set; }

        public string District { get; set; }

        public string States { get; set; }

        public string Country { get; set; }

        public string PinCode { get; set; }

        public DoctorDetailsResponse DoctorDetails { get; set; } = null!;
    }
}

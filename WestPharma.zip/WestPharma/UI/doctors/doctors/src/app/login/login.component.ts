import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder,private router:Router) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
   }

  ngOnInit() {
    
  }

  submitLoginForm() {
    if (this.loginForm.invalid) {
      // Handle invalid form submission
      return;
    }

    const username = this.loginForm.value.username;
    const password = this.loginForm.value.password;

    if(username === password){
      console.log("123");
      const id = 1;
      this.router.navigate(["/appointments",id])
    }

    // Perform login authentication logic here
    // e.g., call an API to validate credentials
    // You can also redirect to a different page upon successful login
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-doctor-details',
  templateUrl: './doctor-details.component.html',
  styleUrls: ['./doctor-details.component.css']
})
export class DoctorDetailsComponent implements OnInit {

  doctor: Doctor | null = null;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const doctorId = params.get('id');
      // Simulated API call or data retrieval logic to fetch the doctor details by ID
      this.doctor = this.getDoctorDetails(doctorId);
    });
  }

  getDoctorDetails(doctorId: string | null): Doctor | null {
    // Simulated doctor data retrieval based on ID
    const doctors: Doctor[] = [
      { id: '1', name: 'Dr. John Doe', specialty: 'Cardiology', description: 'Experienced cardiologist specializing in heart diseases.', contact: 'johndoe@example.com', availability: 'Mon-Fri, 9 AM - 5 PM' },
      { id: '2', name: 'Dr. Jane Smith', specialty: 'Dermatology', description: 'Dermatologist offering services for skin-related issues.', contact: 'janesmith@example.com', availability: 'Tue-Sat, 10 AM - 6 PM' },
      // Add more doctor objects as needed
    ];

    return doctors.find(d => d.id === doctorId) || null;
  }

  scheduleAppointment(): void {
    // Logic to navigate to the appointment scheduling page or display a modal
    console.log('Appointment scheduling logic');
  }

}
interface Doctor {
  id: string;
  name: string;
  specialty: string;
  description: string;
  contact: string;
  availability: string;
}

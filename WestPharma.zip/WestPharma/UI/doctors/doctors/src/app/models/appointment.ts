export interface Appointment {
  date: Date;  
  status: string;
  comments:string;
  id:number;
  doctorId:number;
  name:string;
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppointmentService } from '../services/appointment-service.service';
import { Appointment } from '../models/appointment';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.css']
})
export class AppointmentListComponent implements OnInit {
  doctorId: string; // Assuming the doctor ID is of type string
  appointments: Appointment[] = [];

  constructor(private route: ActivatedRoute, private appointmentService: AppointmentService) {
    this.doctorId = this.route.snapshot.paramMap.get('id')!;
   }

  ngOnInit() {
   
    this.fetchAppointments();
  }

  fetchAppointments() {
    // Assuming you have an AppointmentService that fetches appointments from the server
    this.appointmentService.getAppointmentsForDoctor(this.doctorId).subscribe(
      (appointments: Appointment[]) => {
        this.appointments = appointments;
      },
      () => {
        // Handle error
      }
    );
  }

  updateStatus(appointment: Appointment, status: string) {
    if (status === 'accepted') {
      // Update the status to 'accepted' and save to the database
      appointment.status = 'accepted';
      this.appointmentService.updateAppointmentStatus(appointment).subscribe(
        () => {
          // Success, appointment status updated
        },
        () => {
          // Handle error
        }
      );
    } else if (status === 'rejected') {
      // Ask for comments
      const comments = prompt('Enter comments for rejecting the appointment:');
      if (comments) {
        // Update the status to 'rejected' with comments and save to the database
        appointment.status = 'rejected';
        appointment.comments = comments;
        this.appointmentService.updateAppointmentStatus(appointment).subscribe(
          () => {
            // Success, appointment status updated
          },
          // (error) => {
          //   // Handle error
          // }
        );
      }
    }
  }
}

import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.css']
})
export class AppointmentFormComponent implements OnInit {

  appointmentForm: FormGroup;
  doctor: any;

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute,private datePipe: DatePipe) {
    this.appointmentForm = this.formBuilder.group({
      appointmentDate: [{ value: new Date(), disabled: true }],
      name:['',Validators.required],
      email:['',[Validators.required, Validators.email]],
      mobileNo:['',Validators.required]
    });
  }

  ngOnInit() {
    const serializedData = this.route.snapshot.paramMap.get('state');
    const data = JSON.parse(serializedData!);   
      console.log(data);
      this.doctor = data.doctor;
      this.appointmentForm.setValue({appointmentDate: this.datePipe.transform(data.selectedDate,'yyyy-MM-dd'),name:'',email:'',mobileNo:''})
      //this.appointmentForm.setValue({confirmation: true})
      // this.appointmentForm.controls.appointmentDate.setValue(this.datePipe.transform(this.appointmentDate, 'yyyy-MM-dd'));
      console.log(this.appointmentForm.value);
  }

  confirmBooking() {
    if (this.appointmentForm.valid) {
      // Perform the booking confirmation logic here
      console.log(this.appointmentForm.value);
    }
  }
}

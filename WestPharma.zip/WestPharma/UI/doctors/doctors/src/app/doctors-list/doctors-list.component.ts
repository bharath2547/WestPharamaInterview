import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppointmentService } from '../services/appointment-service.service';
import { DoctorDetailsService } from '../services/doctorDetail.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-doctors-list',
  templateUrl: './doctors-list.component.html',
  styleUrls: ['./doctors-list.component.css']
})
export class DoctorsListComponent implements OnInit {

  specializations: Specialization[] = [];

  doctors: Doctor[] = [];

  specialtyForm: FormGroup;
  selectedSpecialtyId: number | null = null;
  selectedSpecialty: boolean = false;
  filteredDoctors: Doctor[] = [];
  selectedDoctor: any;
  showAppointmentForm: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private _doctorDetailsService: DoctorDetailsService) {
    this.specialtyForm = this.formBuilder.group({
      specialtyControl: [''],
      selectedDate: ['', Validators.required]
    });
  }
  ngOnInit() {
    this._doctorDetailsService.getSepecialization().subscribe(data => {
      data.forEach((element: Specialization) => {
        this.specializations.push(element)
      });
    })
  }
  onSpecializationChange(): void {
    this.selectedSpecialtyId = +this.specialtyForm.get('specialtyControl')?.value;
    this._doctorDetailsService.getDoctorDetails(this.selectedSpecialtyId).subscribe(data => {
      data.forEach((element: Doctor) => {
        this.filteredDoctors.push(element)
      });
    })
    this.selectedSpecialty = true;
  }

  bookAppointment(doctor: Doctor) {
    this.selectedDoctor = doctor;
    console.log(this.selectedDoctor)
    this.showAppointmentForm = true;
  }

  todayDate() {
    return new Date().toISOString().split('T')[0];
  }

  submitAppointment(doctor: Doctor) {
    console.log(this.specialtyForm.value);

    if (this.specialtyForm.invalid && this.specialtyForm.controls.selectedDate.value == "" && !!this.selectedDoctor) {
      return;
    }

    const appointmentDetails = {
      doctor: this.selectedDoctor,
      selectedDate: this.specialtyForm.controls.selectedDate.value
    };
    console.log(appointmentDetails);
    const serializedData = JSON.stringify(appointmentDetails);
    // Redirect to the appointment form with the booking and doctor details
    this.router.navigate(['/appointmentForm', { state: serializedData }]);

    // // Perform your logic here to handle the appointment submission
    // console.log('Appointment Date:', this.specialtyForm.get('selectedDate')?.value);
    // // Reset appointment form
    // this.selectedDoctor = null;
    // this.showAppointmentForm = false;
    // this.specialtyForm.setValue({selectedDate:''});
  }
}

interface Specialization {
  specializationId: number;
  specializationName: string;
  specializationDescription: string;
}

interface Doctor {
  doctorId: number;
  doctorName: string;
  email: string;
  phoneNumber: string;
  description: string;
  address: string;
  specialization: Specialization;
}
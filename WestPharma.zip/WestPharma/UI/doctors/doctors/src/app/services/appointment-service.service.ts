import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Appointment } from '../models/appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private appointments: Appointment[] = [
    { id: 1, doctorId: 1, name: 'John Doe', date: new Date('2023-06-30'), status: 'pending',comments:'' },
    { id: 2, doctorId: 1, name: 'Jane Smith', date: new Date('2023-07-05'), status: 'pending',comments:'' },
    { id: 3, doctorId: 2, name: 'Michael Johnson', date: new Date('2023-07-01'), status: 'pending',comments:'' },
    { id: 4, doctorId: 2, name: 'Sarah Williams', date: new Date('2023-07-03'), status: 'pending' ,comments:''}
  ];

  getAppointmentsForDoctor(doctorId: string): Observable<Appointment[]> {
    const filteredAppointments = this.appointments.filter(appointment => appointment.doctorId.toString() === doctorId);
    return of(filteredAppointments);
  }

  updateAppointmentStatus(appointment: Appointment): Observable<void> {
    // Assuming you have an API or method to save/update the appointment status on the server
    // Here, we simply update the status in the local array
    const appointmentIndex = this.appointments.findIndex(a => a.id === appointment.id);
    if (appointmentIndex > -1) {
      this.appointments[appointmentIndex] = appointment;
    }
    return of();
  }
}

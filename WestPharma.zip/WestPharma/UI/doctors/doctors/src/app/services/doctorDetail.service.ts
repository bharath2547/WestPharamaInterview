import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class DoctorDetailsService {
    constructor(private http: HttpClient) { }

    getSepecialization(): Observable<any> {
        return this.http.get<any>('https://localhost:7274/Specializations')
    }

    getDoctorDetails(id: number): Observable<any> {
        return this.http.get<any>('https://localhost:7274/DoctorDeatils/Specializations/'+id)
    }
}